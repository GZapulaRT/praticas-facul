#ifndef ProcuraMapa_hpp
#define ProcuraMapa_hpp

void pathFind(char*, int, int);

#endif