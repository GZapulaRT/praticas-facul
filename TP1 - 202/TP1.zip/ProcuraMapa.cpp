#include "ProcuraMapa.hpp"

using namespace std;

void pathFind(char* mapa, int x, int y)
{
	if(mapa[x*10+y-1] = '0' && x*10+y-1 >= 0)
}