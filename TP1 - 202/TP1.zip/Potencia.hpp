#ifndef Potencia_hpp
#define Potencia_hpp

int mathPower(int, int);

#endif
